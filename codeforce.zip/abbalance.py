# ab.balance

t = int(input())
for i in range(t):
    s = input()
    print(s[:-1] +s[0])